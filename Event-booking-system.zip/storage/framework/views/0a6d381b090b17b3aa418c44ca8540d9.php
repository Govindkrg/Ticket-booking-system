<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<?php $__env->startSection('title', 'My Bookings'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">My Bookings</h1>

    <?php if($bookings->isEmpty()): ?>
        <div class="alert alert-info">You have no bookings yet.</div>
    <?php else: ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Event Name</th>
                        <th>Date</th>
                        <th>Venue</th>
                        <th>Booking Time</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($booking->event->name); ?></td>
                            <td>
                                <?php echo e(\Carbon\Carbon::parse($booking->event->date)->format('d-m-Y H:i:s')); ?>



                            </td>
                            <td><?php echo e($booking->event->venue); ?></td>
                            <td>

                                <?php echo e(\Carbon\Carbon::parse($booking->event->created_at)->format('d-m-Y H:i:s')); ?>


                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <div style="display: flex; justify-content: center; margin-top: 20px;">
            <?php echo e($bookings->links()); ?>

        </div>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Govind\Desktop\int\Event-booking-system\resources\views/bookings/index.blade.php ENDPATH**/ ?>