<?php $__env->startSection('title', 'Events'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="mb-4">Upcoming Events</h1>

    <div id="booking-message"></div>

    <div class="row">
        <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title"><?php echo e($event->name); ?></h5>
                        <p class="card-text">
                            <strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($event->date)->format('d-m-Y H:i:s')); ?>

                            <br>
                            <strong>Venue:</strong> <?php echo e($event->venue); ?><br>
                            <strong>Available Seats:</strong> <span id="seats-<?php echo e($event->id); ?>"><?php echo e($event->available_seats); ?></span>
                        </p>
                        <?php if(auth()->guard()->check()): ?>
                            <button class="btn btn-primary book-btn" data-event-id="<?php echo e($event->id); ?>">Book Ticket</button>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary">Login to Book</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const bookingMessage = document.getElementById('booking-message');

            document.querySelectorAll('.book-btn').forEach(button => {
                button.addEventListener('click', function() {
                    const eventId = this.getAttribute('data-event-id');

                    fetch('<?php echo e(route("bookings.store")); ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>',
                            'Accept': 'application/json'
                        },
                        body: JSON.stringify({ event_id: eventId })
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            bookingMessage.innerHTML = `
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    ${data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;

                            // Update available seats
                            const seatElement = document.getElementById(`seats-${eventId}`);
                            if (seatElement) {
                                seatElement.textContent = data.available_seats;
                            }

                            // Disable button if no seats left
                            if (data.available_seats <= 0) {
                                this.disabled = true;
                            }
                        } else {
                            bookingMessage.innerHTML = `
                                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                    ${data.message}
                                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                </div>
                            `;
                        }
                    })
                    .catch(error => {
                        bookingMessage.innerHTML = `
                            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                An error occurred: ${error}
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        `;
                    });
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Govind\Desktop\int\Event-booking-system\resources\views/events/index.blade.php ENDPATH**/ ?>