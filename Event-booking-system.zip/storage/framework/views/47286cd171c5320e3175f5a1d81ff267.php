<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ticket Booking System - <?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">

    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="<?php echo e(route('events.index')); ?>">Ticket Booking System</a>
            <div class="navbar-nav">
                <?php if(auth()->guard()->check()): ?>
                    <span class="nav-item nav-link">Welcome, <?php echo e(Auth::user()->name); ?></span>
                    <a class="nav-item nav-link" href="<?php echo e(route('events.index')); ?>">Events</a>
                    <a class="nav-item nav-link" href="<?php echo e(route('bookings.index')); ?>">My Bookings</a>
                    <form action="<?php echo e(route('logout')); ?>" method="POST" class="nav-item">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="nav-link btn btn-link">Logout</button>
                    </form>
                <?php else: ?>
                    <a class="nav-item nav-link" href="<?php echo e(route('login')); ?>">Login</a>
                    <a class="nav-item nav-link" href="<?php echo e(route('register')); ?>">Register</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <?php echo $__env->yieldContent('content'); ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <?php echo $__env->yieldPushContent('scripts'); ?>
    <footer style="background-color: #f0f0f0; padding: 20px 10px; text-align: center; font-family: Arial, sans-serif; margin-top: 40px; border-top: 1px solid #ddd;">
        <p style="margin: 5px 0; font-size: 16px; color: #333;">
          Developed By <strong>Govind</strong> &mdash; This is an <strong>Assignment</strong>
        </p>
        <a href="tel:9616681400" style="display: inline-block; margin-top: 10px; font-size: 18px; color: #007bff; text-decoration: none; font-weight: bold;">
          Contact Us
        </a>
      </footer>

</body>
</html>
<?php /**PATH C:\Users\Govind\Desktop\int\Event-booking-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>